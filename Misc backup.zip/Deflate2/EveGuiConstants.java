/* 
 * This code may be freely distributed
 * and used for any non-commericial purpose, as long as its copyright 
 * notice is retained.  The author assumes absolutely no responsibility 
 * for any harm caused by bugs in the code.
 **/ 

/* 
 * EveGuiConstants.java - coded By st0le [st0le'n'stuff softwarez!] 
 * Website : http://st0lenc0des.googlepages.com 
 * Copyright (c) st0le 2007 
 */ 



public interface EveGuiConstants {
	String[] algorithmNamesArray = {"Deflate Compression"
											};

	String[] extensionArray = {".def"
											};

	final int COMP_HUFFMAN = 9;
	final short DEFLATE_CODE = 0;
	
	final int COMPRESS = 32;
	final int DECOMPRESS = 33;
	}

