/* 
 * This code may be freely distributed
 * and used for any non-commericial purpose, as long as its copyright 
 * notice is retained.  The author assumes absolutely no responsibility 
 * for any harm caused by bugs in the code.
 **/ 

/* 
 * EveFrame.java - coded By st0le [st0le'n'stuff softwarez!] 
 * Website : http://st0lenc0des.googlepages.com 
 * Copyright (c) st0le 2007 
 */ 

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;


public class EveFrame extends JFrame{
	private EveSplash splash;
	private JTabbedPane tabbedPane = new JTabbedPane();
	private EveComp  panCompression;
	private EveAbout panAbout;
	private JLabel  lblBanner;
	
	
	void centerWindow(){
		Dimension screensize = Toolkit.getDefaultToolkit().getScreenSize();
        
        setLocation((screensize.width / 2) - (getSize().width / 2),
                    (screensize.height / 2) - (getSize().height / 2));
	}
	
	EveFrame(){
		 setVisible(false);
		 // splash = new EveSplash(this);  //uncomment on release
		 // splash.doSplashStuff();
		 
		 
		 setTitle("Deflate Compression! by Wira Nov Kurnia Sihombing - 051401087!");
		 setSize(600,500);
		 centerWindow();
		 setLayout(new BorderLayout(5,5));

		 lblBanner = new JLabel("Deflate Compression",SwingConstants.CENTER);
		 lblBanner.setSize(400,25);
		 lblBanner.setFont(new Font("Matura MT Script Capitals",Font.BOLD & Font.ITALIC,50));
		 
		 
		 panCompression = new EveComp(this,false);
		 panAbout = new EveAbout(this,false);
		 
		 tabbedPane.addTab("Utama",panCompression);
		 tabbedPane.addTab("Tentang",panAbout);
		 
		 
		 //The following line enables to use scrolling tabs.
         tabbedPane.setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);
         
		
		 getContentPane().add(lblBanner,BorderLayout.NORTH );
		 getContentPane().add(tabbedPane,BorderLayout.CENTER);
        
         setResizable(false);

		 setVisible(true);
		 
		}
		
	
	
		    
    protected void processWindowEvent(WindowEvent e) {

        if (e.getID() == WindowEvent.WINDOW_CLOSING) {
        
        	//System.exit(0); //remove on release
        	
            int exit = JOptionPane.showConfirmDialog(this, "Keluar?","Konfirmasi",JOptionPane.YES_NO_OPTION);
            if (exit == JOptionPane.YES_OPTION) {
                System.exit(0);
            }
            
        } else {

            super.processWindowEvent(e);
        }
    }
    
    }

