import java.io.*;
import java.util.*;
	
class CheckFile {
	private File firstFile;
	private File secondFile;
	
	private FileInputStream firstFin;
	private BufferedInputStream firstIn;
	
	private FileInputStream secondFin;
	private BufferedInputStream secondIn;
	
	public static void main(String[] args) throws Exception {
		CheckFile chk = new CheckFile();
		chk.doWork();
	}
	
	void doWork() throws Exception {
		firstFile = new File("c:\\testlg.txt");
		secondFile = new File("c:\\test2.txt");
		
		firstFin = new FileInputStream(firstFile);
		firstIn = new BufferedInputStream(firstFin);
		
		secondFin = new FileInputStream(secondFile);
		secondIn = new BufferedInputStream(secondFin);
		
		int len = secondIn.available();
		
		byte firstByte, secondByte;
		
		int jlhError = 0;
		
		// byte[] buff = new byte[50];
		// int numberOfRead = firstFin.read(buff, 0, 50);
		
		// for (int i = 0; i < 50; i++) {
			// System.out.println(buff[i]);
		// }
		// System.out.println(new String(buff));
		// System.out.println(numberOfRead);
		
		//check, compare between 2 files
		for (int i = 0; i < len; i++) {
			firstByte = (byte) firstFin.read();
			secondByte = (byte) secondFin.read();
			// if ((i >= 30845) && (i <= 30860)) {
				// System.out.println("byte (" + i + "), firstByte: " + firstByte + ", secondByte: " + secondByte);
			// }
			if (firstByte == secondByte) {
			}
			else {
				jlhError++;
				System.out.println("Ditemukan error di byte (" + (i) + "), firstByte: " + firstByte +
					", secondByte: " + secondByte);
				break;
			}
		}
		
		// System.out.println("--Jlh Error: " + jlhError);
	}
}