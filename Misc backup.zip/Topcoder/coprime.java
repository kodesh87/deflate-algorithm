import java.util.Scanner;

class coprime {
public static void main(String[] args) {
Scanner in = new Scanner(System.in);
int t, m, n, x, y, z;

t = in.nextInt();

for (x=0; x<t; x++) {
m = in.nextInt();
n = in.nextInt();

if (m<=30) {
z=0;
if((2>=m) && (2<=n)) System.out.println(2);
if((3>=m) && (3<=n)) System.out.println(3);
if((5>=m) && (5<=n)) System.out.println(5);
if((7>=m) && (7<=n)) System.out.println(7);
if((11>=m) && (11<=n)) System.out.println(11);
if((13>=m) && (13<=n)) System.out.println(13);
if((17>=m) && (17<=n)) System.out.println(17);
if((19>=m) && (19<=n)) System.out.println(19);
if((23>=m) && (23<=n)) System.out.println(23);
if((29>=m) && (29<=n)) System.out.println(29);
}
else {
z=m-(m%30);
if ((z+1>=m) && (z+1<=n)) System.out.println(z+1);
if ((z+7>=m) && (z+7<=n)) System.out.println(z+7);
if ((z+11>=m) && (z+11<=n)) System.out.println(z+11);
if ((z+13>=m) && (z+13<=n)) System.out.println(z+13);
if ((z+17>=m) && (z+17<=n)) System.out.println(z+17);
if ((z+19>=m) && (z+19<=n)) System.out.println(z+19);
if ((z+23>=m) && (z+23<=n)) System.out.println(z+23);
if ((z+29>=m) && (z+29<=n)) System.out.println(z+29);
}

m=z+30;
while (m<=n) {
if (m+1<=n) System.out.println(m+1);
if (m+7<=n) System.out.println(m+7);
if (m+11<=n) System.out.println(m+11);
if (m+13<=n) System.out.println(m+13);
if (m+17<=n) System.out.println(m+17);
if (m+19<=n) System.out.println(m+19);
if (m+23<=n) System.out.println(m+23);
if (m+29<=n) System.out.println(m+29);
m=m+30;
}
System.out.println();
}
} 
}