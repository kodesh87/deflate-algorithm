import java.util.*;
import java.io.*;

class Testing {

	BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
	String s;

	void doSomething(String in) {
		System.out.println(in);
	}

	void Testing() {
		input = new BufferedReader(new InputStreamReader(System.in));
	}
	
	public static void main(String[] args) throws Exception {
		Testing runTime = new Testing();
		runTime.doSomething(runTime.input.readLine());
	}

}