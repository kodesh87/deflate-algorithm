import java.util.Scanner;

class Main {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		
		int value;
		
		value = in.nextInt();
		
		int valA[] = new int[value];
		int valB[] = new int[value];
		
		System.out.println(76);
		
		for (int i = 0; i < value; i++) {
			valA[i] = in.nextInt();
			valB[i] = in.nextInt();
		}
		
		for (int i = 0; i < value; i++) {
			System.out.println(valA[i] + "tes" + valB[i]);
		}
	}
}