// import java.util.Scanner;

class TimeTravellingCellar {
	
	public int determineProfit(int[] profit, int[] decay) {
		int maxProfit = 0, minDecay, flagProfit, flagDecay;
		for (int i = 0; i < profit.length; i++) {
			if (maxProfit < profit[i]) {
				flagProfit = i;
				maxProfit =
			}
		}
	}

	public static void main(String[] args) {
		int[] a = {1, 2, 3};
		int[] b = {3, 2, 1};
		
		System.out.println(determineProfit(a, b));
	}
}