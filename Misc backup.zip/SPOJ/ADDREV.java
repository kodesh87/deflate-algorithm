public class Main {

	int inverseValue(int value) {
		String temp = String.valueOf(value);
		int length = temp.length();
		StringBuffer buff = new StringBuffer(length);

		for (int i = length - 1; i >= 0; i--) {
			buff.append(temp.charAt(i));
		}

		temp = new String(buff);
		return Integer.valueOf(temp);
	}

	public static void main(String[] args) throws java.lang.Exception {
		java.io.BufferedReader r = new java.io.BufferedReader(new java.io.InputStreamReader(System.in));
		int testCase = Integer.valueOf(r.readLine());
		int[] btmLimit = new int[10000];
		int[] topLimit = new int[10000];

		for (int i = 0; i < testCase; i++) {
			String inputStr = r.readLine();
			int indexOfWhiteSpace = inputStr.indexOf(' ');
			btmLimit[i] = Integer.valueOf(inputStr.substring(0, indexOfWhiteSpace));
			topLimit[i] = Integer.valueOf(inputStr.substring(indexOfWhiteSpace + 1));
		}

		Main main = new Main();

		for (int i = 0; i < testCase; i++) {
			System.out.println(main.inverseValue((main.inverseValue(btmLimit[i]) + (main.inverseValue(topLimit[i])))));
		}
	}
}