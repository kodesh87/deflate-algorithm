public class Main {

	int[] primeNumber = new int[100000];
	int maxArray = 0;

	void initialization(int limit) {
		int count = 1, checkArray, k;
		while (count < limit) {
			for (checkArray = 0; checkArray < maxArray; checkArray++) {
				if ((count % primeNumber[checkArray]) == 0) {
					break;
				}
			}

			if (checkArray == 0) {
				k = 2;
			}
			else {
				k = primeNumber[checkArray - 1];
			}

			for (; k < count; k++) {
				if ((count % k) == 0) {
					break;
				}
			}
			if (count == k) {
				primeNumber[maxArray] = count;
				maxArray++;
			}
			count++;
		}
	}

	public static void main(String[] args) throws java.lang.Exception {
		java.io.BufferedReader r = new java.io.BufferedReader(new java.io.InputStreamReader(System.in));
		int testCase = Integer.valueOf(r.readLine());
		int[] btmLimit = new int[10];
		int[] topLimit = new int[10];

		for (int i = 0; i < testCase; i++) {
			String inputStr = r.readLine();
			int indexOfWhiteSpace = inputStr.indexOf(' ');
			btmLimit[i] = Integer.valueOf(inputStr.substring(0, indexOfWhiteSpace));
			topLimit[i] = Integer.valueOf(inputStr.substring(indexOfWhiteSpace + 1));
		}

		Main main;
		int checkArray, k;

		for (int i = 0; i < testCase; i++) {
			main = new Main();
			main.initialization(btmLimit[i]);

			for (int j = btmLimit[i]; j <= topLimit[i]; j++) {
				for (checkArray = 0; checkArray < main.maxArray; checkArray++) {
					if ((j % main.primeNumber[checkArray]) == 0) {
						break;
					}
				}

				if (checkArray == 0) {
					k = 2;
				}
				else {
					k = main.primeNumber[checkArray - 1];
				}

				for (; k < j; k++) {
					if ((j % k) == 0) {
						break;
					}
				}
				if (j == k) {
					System.out.println(j);
					main.primeNumber[main.maxArray] = j;
					main.maxArray++;
				}
			}
			System.out.println();
		}
	}
}