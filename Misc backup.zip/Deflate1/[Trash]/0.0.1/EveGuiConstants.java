/* 
 * This code may be freely distributed
 * and used for any non-commericial purpose, as long as its copyright 
 * notice is retained.  The author assumes absolutely no responsibility 
 * for any harm caused by bugs in the code.
 **/ 

/* 
 * EveGuiConstants.java - coded By st0le [st0le'n'stuff softwarez!] 
 * Website : http://st0lenc0des.googlepages.com 
 * Copyright (c) st0le 2007 
 */ 



public interface EveGuiConstants {
	String[] algorithmNamesArray = {		"Deflate Compression"
											// "Shannon Fano Compression",
											// "GZip Compression",
											// "Cosmo Compression",
											// "JunkCode Binary Compression",
											// "RLE Compressor",
											// "LZW Compressor"
											};

	String[] extensionArray = {				".def"
											// ".sfe",
											// ".gz",
											// ".cos",
											// ".jbe",
											// ".rle",
											// ".lzw"
											};

	final int COMP_HUFFMAN = 0;
	// final int COMP_SHANNONFANO = 1;
	// final int COMP_GZIP = 2;
	// final int COMP_COSMO = 3;
	// final int COMP_JBC = 4;
	// final int COMP_RLE = 5;
	// final int COMP_LZW = 6;
	final int DEFLATER_CODE = 0;
	
	final int COMPRESS = 32;
	final int DECOMPRESS = 33;
	}

