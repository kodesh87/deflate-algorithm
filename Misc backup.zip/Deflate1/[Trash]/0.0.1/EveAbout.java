/* 
 * This code may be freely distributed
 * and used for any non-commericial purpose, as long as its copyright 
 * notice is retained.  The author assumes absolutely no responsibility 
 * for any harm caused by bugs in the code.
 **/ 

/* 
 * EveAbout.java - coded By st0le [st0le'n'stuff softwarez!] 
 * Website : http://st0lenc0des.googlepages.com 
 * Copyright (c) st0le 2007 
 */ 

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class EveAbout extends JPanel {
	JLabel splashImage;
	
	EveAbout(JFrame parent,boolean isDblBuf){
		super(isDblBuf);
		
		setLayout(new BorderLayout());
        splashImage = new JLabel(new ImageIcon(getClass().getResource(
                   "resources/images/eve_about.jpg")));
        
                   
        add(splashImage, BorderLayout.CENTER);
        
        splashImage.setBorder(BorderFactory.createLineBorder(
                          new Color(75, 75, 75)));

		}
		
		
} 

