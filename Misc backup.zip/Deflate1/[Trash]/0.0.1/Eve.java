/* 
 * This code may be freely distributed
 * and used for any non-commericial purpose, as long as its copyright 
 * notice is retained.  The author assumes absolutely no responsibility 
 * for any harm caused by bugs in the code.
 **/ 

/* 
 * Eve.java - coded By st0le [st0le'n'stuff softwarez!] 
 * Website : http://st0lenc0des.googlepages.com 
 * Copyright (c) st0le 2007 
 */ 


/*
 * Greetings to all Java/C/C++/ASM Coders *waves* 
 *
 * Thanks to David Huffman, Abraham Lempel, Jacob Ziv, Terry Welch,
 * Claude Shannon, Robert Fano, Jean-loup Gailly and Mark Adler. 
 *
 * Credits :
 * Kulvir Singh Bhogal and Javid Jamae - For the GZip Article (and Code)
 * JunkCode (www.infogreg.com) - For the JBC Algorithm.
 *
 * Notes : 
 * 1) Cosmo (Fixed Length Encoder) Was Named After The Character 
 *    of the same Name From "The Fairly Odd Parents".
 * 2) EVE IS NOT MEMORY OPTIMIZED AT ALL!! It Uses a Lot of Useless Memory
 *    which hopefully i'll fix if i get the time.
 *
 * Eve was Written using JCreator.
 * The C Grade Graphics were Done by myself 
 * using "PhotoFiltre" (Light Weight Image Editor)
 *
 * Music While Coding : Coldplay, Maroon 5, Oasis, Aqualung, Keane, Avril Lavigne.
 *
 * Ciao!
 **/
 
 
import javax.swing.*;


public class Eve{
	
	private static void createAndShowGUI(){
		EveFrame mainframe = new EveFrame();
		mainframe.setVisible(true);
	}
	
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable()
			{
				public void run() {
					createAndShowGUI();
				}
			}
		);
    }
}

