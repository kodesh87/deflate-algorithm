import java.io.*;

class Debug{
	public static void main(String[] args) {
		Debug idebug = new Debug();
		
		String fileName = "E:\\My Documents\\Graphic1.jpg";
		FileInputStream fin;
		BufferedInputStream in;
		int fileLen;
		in = null;
		
		try {
			fin = new FileInputStream(fileName);
			in = new BufferedInputStream(fin);
		} catch(Exception e){}
		
		fileLen = 0;
		
		try{
			fileLen = in.available();
			if(fileLen == 0);
		} catch(IOException e)
		{
		}
		
		System.out.println("---\n" + fileName );
		System.out.println(fileLen + "\n---");
		
		long position = 0;
		
		int extraPosition = 10000;
		
		StringBuffer strBuff = new StringBuffer();
		
		//Begin
		System.out.println("begin");
		for(int i=0; i<extraPosition; i++) {
			char k='5';
			System.out.println(i);
			try {
				k = (char)in.read();}
			catch (Exception e){}
			strBuff.append(k);
		}
	}
}