/* 
 * This code may be freely distributed
 * and used for any non-commericial purpose, as long as its copyright 
 * notice is retained.  The author assumes absolutely no responsibility 
 * for any harm caused by bugs in the code.
 **/ 

/* 
 * huffmanSignature.java - coded By st0le [st0le'n'stuff softwarez!] 
 * Website : http://st0lenc0des.googlepages.com 
 * Copyright (c) st0le 2007 
 */ 

package CHuffmanCompressor;

public interface huffmanSignature{
	final String hSignature = "SHE";
	final int MAXCHARS = 256;
	final String strExtension = ".huf";

	}

