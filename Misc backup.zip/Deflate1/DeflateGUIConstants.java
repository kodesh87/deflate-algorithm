public interface DeflateGUIConstants {
	String[] algorithmNamesArray = {"Deflate Compression"};

	String[] extensionArray = {".def"};

	final int COMP_HUFFMAN = 9;
	final short DEFLATE_CODE = 0;
	
	final int COMPRESS = 32;
	final int DECOMPRESS = 33;
}

