package Engine;

public class Container implements ISignature{
	
	// byte[] searchW = new byte[MAXSEARCHWLEN]; //32768
	// byte[] lookAheadW = new byte[MAXLOOKAHEADWLEN]; //258 
	
	//search 0..32767 | space 32768 | 32769..33026.
	//MAXSEARCHWLEN + MAXLOOKAHEADWLEN + 1 = 33027
	byte[] window = new byte[MAXSEARCHWLEN + MAXLOOKAHEADWLEN + 1];
	
	//L stand for Length and Lazy
	int bestL, bestOffset, bestLL, bestOffsetL;
	int totalSearchW, totalLookAheadW, freeSearchW;
		
	public Container() {
		totalSearchW = 0; totalLookAheadW = 0;
		freeSearchW = MAXSEARCHWLEN;
	}
	
	//Design for searchW
	void fillSearchW(int length) {
		if (freeSearchW == MAXSEARCHWLEN) {
			freeSearchW -= length;
			System.arraycopy(lookAheadW, 0, searchW, freeSearchW, length);
			totalSearchW += length;
		}
		else if (freeSearchW == 0) {
			System.arraycopy(searchW, length, searchW, 0, (MAXSEARCHWLEN - length));
			System.arraycopy(lookAheadW, 0, searchW, (totalSearchW - length), length);
		}
		else if ((freeSearchW - length) >= 0) {
			int markStart = freeSearchW;
			freeSearchW -= length;
			System.arraycopy(searchW, markStart, searchW, freeSearchW, totalSearchW);
			int markStartLookAheadW = MAXSEARCHWLEN - length;
			System.arraycopy(lookAheadW, 0, searchW, markStartLookAheadW, length);
			totalSearchW += length;
		}
		else if ((freeSearchW - length) < 0) {
			int getOnly = MAXSEARCHWLEN - length;
			System.arraycopy(searchW, freeSearchW, searchW, 0, getOnly);
			System.arraycopy(lookAheadW, 0, searchW, getOnly, length);
			freeSearchW = 0;
			totalSearchW = MAXSEARCHWLEN;
		}
		else {
			System.out.println("ERROR");
		}
	}
	
	//Design for looakAheadW
	int availableLookAheadW() {
		return MAXLOOKAHEADWLEN - totalLookAheadW;
	}
	
	void fillLookAheadW(byte[] temp) {
		if ((totalLookAheadW + temp.length) > MAXLOOKAHEADWLEN) {
			int free = MAXLOOKAHEADWLEN - totalLookAheadW;
			int markStart = temp.length - free;
			totalLookAheadW -= markStart;
			System.arraycopy(lookAheadW, markStart, lookAheadW, 0, totalLookAheadW);	
		}
		System.arraycopy(temp, 0, lookAheadW, totalLookAheadW, temp.length);
		totalLookAheadW += temp.length;
	}
	
	void delLookAheadW(int length) {
		totalLookAheadW -= length;
		System.arraycopy(lookAheadW, length, lookAheadW, 0, totalLookAheadW);
	}
	
	void trace(int length) {
		int count = 0;
		int matchL, count2, currOffset, currPosition;
		bestL = 0; bestOffset = 0;
		boolean found = false;
		
		while ((++count <= MAXSEARCHWLEN) && (found != true)) {
			currPosition = MAXSEARCHWLEN - count;
			
			if (currPosition < freeSearchW) { //crossing the limit
				break;
			}
			
			count2 = 0;
			matchL = 0;
			currOffset = currPosition;
			
			// System.out.println("currPosition value is " + currPosition);
			// System.out.println("count2 value is " + count2);
			// System.out.println("matchL value is " + matchL);
			// System.out.println("length value is " + length);
			// System.out.println("freeSearchW value is " + freeSearchW);
			
			while ((currPosition < MAXSEARCHWLEN) && (count2 < MAXLOOKAHEADWLEN) && (matchL < length)) {
				// System.out.println("Perulangan pertama, mencari yg matched");
				if (searchW[currPosition] == lookAheadW[count2]) {
					matchL++;
					currPosition++;
					count2++;
				}
				else {
					break;
				}
			}
			
			if (matchL > bestL) {
				bestL = matchL;
				bestOffset = MAXSEARCHWLEN - currOffset;
				// System.out.println("matchL value is " + matchL);
				// System.out.println("bestL value is " + matchL);
				// System.out.println("bestL value is " + bestOffset);
			}
			
			if (bestL == length) {
				// System.out.println("Found best length");
				found = true;
			}
		}
	}
	
	void lazySearch(int length) {
		int count = 0;
		int matchL, count2, currOffset, currPosition;
		bestLL = 0; bestOffsetL = 0;
		boolean found = false;
		
		while ((++count <= MAXSEARCHWLEN) && (found != true)) {
			currPosition = MAXSEARCHWLEN - count;
			
			if (currPosition < freeSearchW) { //crossing the limit
				break;
			}
			
			count2 = 1;
			matchL = 0;
			currOffset = currPosition;
			
			while ((currPosition < MAXSEARCHWLEN) && (count2 < MAXLOOKAHEADWLEN) && (matchL < length)) {
				if (searchW[currPosition] == lookAheadW[count2]) {
					matchL++;
					currPosition++;
					count2++;
				}
				else {
					break;
				}
			}
			
			if (matchL > bestLL) {
				bestLL = matchL;
				bestOffsetL = MAXSEARCHWLEN - currOffset;
			}
			
			if (bestLL == length) {
				found = true;
			}
		}
	}
}