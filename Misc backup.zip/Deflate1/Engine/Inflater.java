package Engine;

import java.io.*;
import FileBitIO.*;

public class Inflater implements ISignature{
	private String fileName,outputFilename;
	
	private long fileLen=0,outputFilelen;
	
	private FileOutputStream outf;
	private String gSummary;

	
	public Inflater(String txt,String txt2){
		loadFile(txt,txt2);
	}
		
	public void loadFile(String txt,String txt2){
		fileName = txt;
		outputFilename = txt2;
		gSummary = "";
	}
	
	public boolean decodeFile() throws Exception{		
		if(fileName.length() == 0) return false;
		
		long i;
		int j;
		CFileBitReader fin = new CFileBitReader(fileName);
		fileLen = fin.available();

		String buf = new String(fin._getBytes(dSignature.length()));
		if(!buf.equals(dSignature)) return false;
		outputFilelen = fin.getValueOfBytes(4);
		// System.out.println(outputFilelen);
		
		gSummary  += ("Compressed File Size : "+ fileLen + "\n");
		gSummary  += ("Original   File Size : "+ outputFilelen + "\n");
				
		try {
			outf = new FileOutputStream(outputFilename);
			i = 0;
			int k, ch, modeCompression, len = 0, tempLen = 0, n = 0;
			String strLen, compStrLen;
			byte[] header = new byte[4], buffer = new byte[1024];
			
			while(i < outputFilelen){
				
				modeCompression = (int) fin.getValueOfBytes(1)/32;
				System.out.println(modeCompression);
				
				switch(modeCompression){
					case 0://Block TYPE 000
							header = fin._getBytes(4);
							
							if(!((header[0] == ~header[2]) && (header[1] == ~header[3]))) {
								throw new Exception("Corrupted File!");
							}
							
							n = MAXBLOCKSIZE_NOCOMPRESSION;
								
							while (n > 0){
								if ((n-1024) >= 0) {
									buffer = fin._getBytes(1024);
									outf.write(buffer, 0, 1024);
									n -= 1024;
								}
								else {
									buffer = fin._getBytes(n);
									System.out.println(n);
									outf.write(buffer, 0, n);
									n -= n;
								}
							}	
							
							i += MAXBLOCKSIZE_NOCOMPRESSION;
							break;
					case 4://Block TYPE 100
							header = fin._getBytes(4);
							
							if(!((header[0] == ~header[2]) && (header[1] == ~header[3]))) {
								throw new Exception("Corrupted File!");
							}
							
							tempLen = header[1];
							if (tempLen < 0) tempLen += 256;
							len += tempLen;
							
							tempLen = header[0];
							if (tempLen < 0) tempLen += 256;
							len += tempLen << 8;
							tempLen = len;
							
							System.out.println(len);
								
							while (len > 0){
								if ((len-1024) >= 0) {
									buffer = fin._getBytes(1024);
									outf.write(buffer, 0, 1024);
									len -= 1024;
								}
								else {
									buffer = fin._getBytes(len);
									System.out.println(len);
									outf.write(buffer, 0, len);
									len -= len;
								}
							}	

							i += tempLen;							
							break;
					case 1://Block TYPE 001
							break;
					case 5://Block TYPE 101
							break;						
					case 2://Block TYPE 010
							break;
					case 6://Block TYPE 110
							break;							
				}
			}
		
			outf.close();
			return true;
		} 
		catch(Exception e){
			throw e;
		}
	}
	
	String complementBinaryStr(String txt){
		int i = 0;
		StringBuffer strBuff = new StringBuffer();
		while(i < (txt.length())) {
			if(txt.charAt(i) == '0') {
				strBuff.append("1");
			}
			else {
				strBuff.append("0");
			}
			i++;
		}
		return new String(strBuff);
	}	
	
	String leftPadder(String txt,int n){
		while(txt.length() < n )
			txt =  "0" + txt;
		return txt;
	}
	
	String rightPadder(String txt,int n){
		while(txt.length() < n )
			txt += "0";
		return txt;
	}
		
	public String getSummary(){
		return gSummary;
	}
}