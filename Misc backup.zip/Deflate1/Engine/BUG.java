		while(rFile.available() > 0){ //Find the escape, ????
			// searchWindowStart = (lcount-MAXSEARCHWLEN >=0) ? lcount-MAXSEARCHWLEN : 0;
			// lookAheadWindowEnd = (lcount+MAXLOOKAHEADWLEN < fileLen) ? lcount+MAXLOOKAHEADWLEN : fileLen;
			// lenLookAheadWindow = lookAheadWindow.length();
			// zeroLookAheadWindow = 258 - lenLookAheadWindow;
			// System.out.println("lenLookAheadWindow = " + lenLookAheadWindow);
			
			//Fill the lookAheadWindow
			if((zeroLookAheadW = co.availableLookAheadW()) <= rFile.available()){
				co.fillLookAheadW(rFile._getBytes(zeroLookAheadW));
				// lookAheadWindowBuff.append(new String(rFile._getBytes(zeroLookAheadWindow)));
				// System.out.println("Kalang pertama if, LookAheadWindow = " + lookAheadWindow);
			} else{
				co.fillLookAheadW(rFile._getBytes(rFile.available()));
				// lookAheadWindowBuff.append(new String(rFile._getBytes((int) rFile.available())));
				// System.out.println("Kalang kedua if, LookAheadWindow = " + lookAheadWindow);
			}
			
			// lookAheadWindow = new String(lookAheadWindowBuff);
			
			// lenLookAheadWindow = lookAheadWindow.length();
			// searchString = lookAheadWindow.substring(0, 1);
			// System.out.println("new lenLookAheadWindow = " + lenLookAheadWindow);
			// System.out.println("searchString = " + searchString);
			
			// matchLength++; //Try with 1 match
			// lastFound = true; //Manipulate 1st try
			
			System.out.println("nice length = " + nice_length);
			while ((matchLength <= nice_length) && (lastFound == true) && (matchLength <= lenLookAheadWindow)) { // the '=' with guess matchLength
				searchString = lookAheadWindow.substring(0, matchLength);
				rOffset = searchWindow.lastIndexOf(searchString);
				System.out.println("searchString = " + searchString);
				System.out.println("matchLength = " + matchLength);
				if (rOffset != -1) {
					matchLength++; //Try another guess
				}
				else {
					lastFound = false;
				}
			}
			
			if (--matchLength == 0) { //the real value, the if will "output the literal"
				zszapre.hCodes[(int) lookAheadWindow.charAt(0)];  // dFile._putByte((int) lookAheadWindow.substring(0, 1));
				searchWindow = fillSearchBuffer(searchWindow, lookAheadWindow.substring(0, 1));
				lookAheadWindow = lookAheadWindow.substring(1);
				//TO DO: (1) SearchWindow --> Append, think about another routine to control the Search Window sure is below the max 32K
				//       (2) lookAheadWindow --> delete the last character 
				//DONE But not tested yet.
				continue;
			}
			
			//Do lazy search
 			if (matchLength < max_lazy) {
				System.out.println("lazy search");
				matchLength2++; //Try with 1 match
				lastFound = true; //Manipulate 1st try
				
				while ((matchLength2 <= nice_length) && (lastFound == true) && (matchLength2 <= lenLookAheadWindow)) { // the '=' with guess matchLength
					searchString = lookAheadWindow.substring(1, matchLength2 + 1);
					rOffset2 = searchWindow.lastIndexOf(searchString);
					System.out.println("searchString = " + searchString);
					
					if (rOffset2 != -1) {
						matchLength++; //Try another guess
						System.out.println("matchLength = " + matchLength);
					}
					else {
						lastFound = false;
					}
				}
			}
			
			if (matchLength > (matchLength2 + 2)) {
				if (matchLength > 2) {
					//output the length 1st then followed by distance 2nd
				}
				else {
					
				}
			}
			else {
			}
			// }
			//Save the output
			// dFile.putBits(hCodes[(int)ch]);
			lcount++;
		}
	}