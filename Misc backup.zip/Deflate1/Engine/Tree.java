public class Tree {
	public int Len;
	public int Code;
	
	public Tree() {
		Len = 0;
		Code = 0;
	}
}