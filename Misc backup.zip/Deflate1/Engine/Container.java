package Engine;

public class Container implements ISignature{
	
	// byte[] searchW = new byte[MAXSEARCHWLEN]; //32768
	// byte[] lookAheadW = new byte[MAXLOOKAHEADWLEN]; //258 
	
	//search 0..32767 | space 32768 | 32769..33026.
	//MAXSEARCHWLEN + MAXLOOKAHEADWLEN + 1 = 33027
	byte[] window = new byte[MAXSEARCHWLEN + MAXLOOKAHEADWLEN];
	
	//L stand for Length and Lazy
	int bestL, bestOffset, bestLL, bestOffsetL;
	int totalSearchW, totalLookAheadW, freeSearchW;
	final int STARTSEARCHW = 0, ENDSEARCHW = 32767;
	final int STARTLOOKAHEADW = 32768, ENDLOOKAHEADW = 33025;
		
	public Container() {
		totalSearchW = 0; totalLookAheadW = 0;
		freeSearchW = MAXSEARCHWLEN;
	}
	
	//Design for searchW
	//UPDATED COMPOSITE WINDOW
	void fillSearchW(int length) {
		if (freeSearchW == MAXSEARCHWLEN) {
			freeSearchW -= length;
			System.arraycopy(window, STARTLOOKAHEADW, window, freeSearchW, length);
			totalSearchW += length;
		}
		else if (freeSearchW == 0) {
			System.arraycopy(window, length, window, 0, (MAXSEARCHWLEN - length));
			System.arraycopy(window, STARTLOOKAHEADW, window, (totalSearchW - length), length);
			//If freeSearchW is zero, no need update totalSearchW, because it means totalSearchW always FULL next time
		}
		else if ((freeSearchW - length) >= 0) {
			int markStart = freeSearchW;
			freeSearchW -= length;
			System.arraycopy(window, markStart, window, freeSearchW, totalSearchW);
			int markStartLookAheadW = MAXSEARCHWLEN - length;
			System.arraycopy(window, STARTLOOKAHEADW, window, markStartLookAheadW, length);
			totalSearchW += length;
		}
		else if ((freeSearchW - length) < 0) {
			int getOnly = MAXSEARCHWLEN - length;
			System.arraycopy(window, freeSearchW, window, 0, getOnly);
			System.arraycopy(window, STARTLOOKAHEADW, window, getOnly, length);
			freeSearchW = 0;
			totalSearchW = MAXSEARCHWLEN;
		}
		else {
			System.out.println("ERROR");
		}
	}
	
	//Design for looakAheadW, NO NEED UPDATE
	int availableLookAheadW() {
		return MAXLOOKAHEADWLEN - totalLookAheadW;
	}
	
	//UPDATED COMPOSITE WINDOW
	void fillLookAheadW(byte[] temp) {
		int markStartR;
		// for (int i = 0; i < temp.length; i++) {
			// System.out.print(temp[i]);
		// }
		if ((totalLookAheadW + temp.length) > MAXLOOKAHEADWLEN) {
			int free = MAXLOOKAHEADWLEN - totalLookAheadW;
			int markStart = temp.length - free;
			markStartR = markStart + STARTLOOKAHEADW;
			totalLookAheadW -= markStart;
			System.arraycopy(window, markStart, window, STARTLOOKAHEADW, totalLookAheadW);	
		}
		markStartR = totalLookAheadW + STARTLOOKAHEADW;
		System.arraycopy(temp, 0, window, markStartR, temp.length);
		totalLookAheadW += temp.length;
	}
	
	int getLookAheadW(int index) {
		return window[STARTLOOKAHEADW + index];
	}
	
	//UPDATED COMPOSITE WINDOW
	void delLookAheadW(int length) {
		totalLookAheadW -= length;
		System.arraycopy(window, length + STARTLOOKAHEADW, window, STARTLOOKAHEADW, totalLookAheadW);
	}
	
	//UPDATED COMPOSITE WINDOW
	void trace(int length) {
		int count = 0;
		int matchL, count2, currOffset, currPosSearchW, currPosLookAheadW;
		boolean found = false;
		
		while ((++count <= totalSearchW) && (found != true)) {
			currPosSearchW = MAXSEARCHWLEN - count;
			
			if (currPosSearchW < freeSearchW) { //crossing the limit
				break;
			}
			
			count2 = 1;
			matchL = 0;
			currOffset = currPosSearchW;
			currPosLookAheadW = STARTLOOKAHEADW;
			// System.out.println("currPosition value is " + currPosition);
			// System.out.println("count2 value is " + count2);
			// System.out.println("matchL value is " + matchL);
			// System.out.println("length value is " + length);
			// System.out.println("freeSearchW value is " + freeSearchW);
			
			// Need the control to ensure that not cross the index boundary?
			// DISABLE: (currPosSearchW < MAXSEARCHWLEN) &&  && 
			while ((matchL < length) && (currPosLookAheadW < ENDLOOKAHEADW) && (count2 <= totalLookAheadW)) { 
				// System.out.println("Perulangan mencari match length");
				// System.out.println("currPosSearchW: " + currPosSearchW + "currPosLookAheadW: " + currPosLookAheadW);
				if (window[currPosSearchW] == window[currPosLookAheadW]) {
					matchL++;
					currPosSearchW++;
					currPosLookAheadW++;
					count2++;
				}
				else {
					break;
				}
			}
			
			if (matchL > bestL) {
				bestL = matchL;
				bestOffset = MAXSEARCHWLEN - currOffset;
				// System.out.println("matchL value is " + matchL);
				// System.out.println("bestL value is " + matchL);
				// System.out.println("bestL value is " + bestOffset);
			}
			
			if (bestL == length) {
				// System.out.println("Found best length");
				found = true;
			}
		}
	}
	
	//UPDATED COMPOSITE WINDOW
	void lazySearch(int length) {
		int count = 0;
		int matchL, count2, currOffset, currPosSearchW, currPosLookAheadW;
		boolean found = false;
		
		while ((++count <= totalSearchW) && (found != true)) {
			currPosSearchW = MAXSEARCHWLEN - count;
			
			if (currPosSearchW < freeSearchW) { //crossing the limit
				break;
			}
			
			count2 = 2;
			matchL = 0;
			currOffset = currPosSearchW;
			currPosLookAheadW = STARTLOOKAHEADW + 1; //Skip the 1st Byte for Lazy
			
			//DISABLE: (currPosSearchW < MAXSEARCHWLEN) && (count2 < MAXLOOKAHEADWLEN) && (matchL < length)
			while ((matchL < length) && (currPosLookAheadW < ENDLOOKAHEADW) && (count2 <= totalLookAheadW)) {
				if (window[currPosSearchW] == window[currPosLookAheadW]) {
					matchL++;
					currPosSearchW++;
					currPosLookAheadW++;
					count2++;
				}
				else {
					break;
				}
			}
			
			if (matchL > bestLL) {
				bestLL = matchL;
				bestOffsetL = MAXSEARCHWLEN - currOffset;
			}
			
			if (bestLL == length) {
				found = true;
			}
		}
	}
	
	void initialization () {
		bestL = 0;
		bestOffset = 0;
		bestLL = 0;
		bestOffsetL = 0;
	}
	
	//DEBUG
	void printSearchW() {
		byte[] temp = new byte[totalSearchW];
		System.arraycopy(window, ENDSEARCHW + 1 - totalSearchW, temp, 0, totalSearchW);
		String str = new String(temp);
		System.out.println(str);
		// for (int i = (ENDSEARCHW + 1 - totalSearchW); i < (ENDSEARCHW + 1); i++) {
			// System.out.print(window[i]);
			// System.out.println();
		// }
	}
	
	void printLookAheadW() {
		byte[] temp = new byte[totalLookAheadW];
		System.arraycopy(window, STARTLOOKAHEADW, temp, 0, totalLookAheadW);
		String str = new String(temp);
		System.out.println(str);
		// for (int i = (STARTLOOKAHEADW); i < (STARTLOOKAHEADW + totalLookAheadW); i++) {
			// System.out.print(window[i]);
			// System.out.println();
		// }
	}
}