package Engine;

import java.io.*;
import java.util.*;
import FileBitIO.*;

public class Deflater implements ISignature{

	private String fileName,outputFilename;
	
	CFileBitWriter dFile;
	CFileBitReader rFile;
	
	String searchWindow, lookAheadWindow;
	int modeCompression;
	String strByte, header;
  
	long lcount = 0;
	
	private long fileLen=0,outputFilelen;
	// private FileInputStream fin;
	// private BufferedInputStream in;	
	private String gSummary;
	
	static class Config{
		int max_lazy;    // do not perform lazy search above this match length
		int nice_length; // quit search above this match length
		Config(int max_lazy, int nice_length){
			this.max_lazy=max_lazy;
			this.nice_length=nice_length;
		}
	}
	
	static final private Config[] config_table;    
	static{
		config_table=new Config[3];
		//                         lazy  nice
		config_table[0]=new Config(5,   16);
		config_table[1]=new Config(16,  128);
		config_table[2]=new Config(258,  258);
    }
	
	//Constructor
	public Deflater(String txt,String txt2, int mode) throws Exception{
		loadFile(txt,txt2);
		modeCompression = mode;
	}
	
	public void loadFile(String txt,String txt2) throws Exception{
		fileName = txt;
		outputFilename = txt2;
		dFile = new CFileBitWriter(outputFilename);
	}
	
	
	public boolean encodeFile() throws Exception{
		
		if(fileName.length() == 0) return false;
		
		try{
			rFile = new CFileBitReader(fileName);
			// fin = new FileInputStream(fileName);
			// in = new BufferedInputStream(fin);
		} catch(Exception e){ throw e; }
		
		try{
			fileLen = rFile.available();
			if(fileLen == 0) throw new Exception("Isi file kosong!");
			gSummary += ("File Size : "+ fileLen + "\n");
		} catch(IOException e)
		{
			throw e;
		}
		// System.out.println("Ops pertama");
		dFile._putString(dSignature);
		// System.out.println("Ops pertama");
		dFile.putValue(fileLen);
		// System.out.println("Ops Kedua");
		if(modeCompression == NO_COMPRESSION) {
			doStore();
		}
		else {
			doCompression(config_table[modeCompression].max_lazy, config_table[modeCompression].nice_length);
		}
		
		dFile.closeFile();
		outputFilelen =  new File(outputFilename).length();
		float cratio = (float)(((outputFilelen)*100)/(float)fileLen);
		gSummary += ("Compressed File Size : " + outputFilelen + "\n");
		gSummary += ("Compression Ratio : " + cratio + "%" + "\n");
		return true;
	}
	
	//Mode: No Compression
	void doStore() throws Exception{
		int i = 0, n = 0;
		String strLen;
		byte[] buffer; 
		while(lcount < fileLen){
			// System.out.println("while pertama");
			if((fileLen-lcount) >= MAXBLOCKSIZE_NOCOMPRESSION){
				buffer = new byte[5];
				buffer[0] = (byte) 0;
				buffer[1] = (byte) 255;
				buffer[2] = (byte) 255;
				buffer[3] = (byte) 0;
				buffer[4] = (byte) 0;
				
				dFile.putBytes(buffer, 5);
				
				n = MAXBLOCKSIZE_NOCOMPRESSION;
				buffer = new byte[1024];
				
				while (n > 0){
					if ((n-1024) >= 0) {
						buffer = rFile._getBytes(1024);
						dFile.putBytes(buffer, 1024);
						n -= 1024;
					}
					else {
						buffer = new byte[n];
						buffer = rFile._getBytes(n);
						dFile.putBytes(buffer, n);
						n -= n;
					}
				}				
				lcount += MAXBLOCKSIZE_NOCOMPRESSION;
			}
			else {
				long diff = fileLen - lcount;
				// Sy
				
				buffer = new byte[5];
				buffer[0] = (byte) 128;
				buffer[1] = (byte) (diff>>>8);
				// System.out.println(buffer[1]);
				buffer[2] = (byte) (diff%256);
				// System.out.println(buffer[2]);
				buffer[3] = (byte) ~buffer[1];
				// System.out.println(buffer[3]);
				buffer[4] = (byte) ~buffer[2];
				// System.out.println(buffer[4]);
				
				dFile.putBytes(buffer, 5);
				n = (int) diff;
				// System.out.println(diff);
				
				while (n > 0){
					if ((n-1024) >= 0) {
						buffer = new byte[1024];
						buffer = rFile._getBytes(1024);
						dFile.putBytes(buffer, 1024);
						n -= 1024;
					}
					else {
						buffer = new byte[n];
						buffer = rFile._getBytes(n);
						dFile.putBytes(buffer, n);
						n -= n;
					}
				}	
				lcount = fileLen;
			}
		}
	}
	
	//Mode: Compression
	void doCompression(int max_lazy, int nice_length) throws Exception{
		// System.out.println("Come into doCompression() with mode: " + modeCompression);
				
		PrefixTree pre = new PrefixTree();
		Container co = new Container();
		
		int zeroLookAheadW; boolean Debug = true;
		
		long totalUnProcessed = rFile.available();
		// System.out.println(totalUnProcessed);
		
		while ((rFile.available() > 0) || (totalUnProcessed != 0)){ 
			// System.out.println("Masih ada yg blom di proses = " + totalUnProcessed);
			if((zeroLookAheadW = co.availableLookAheadW()) <= rFile.available()){
				// System.out.println("Terisi penuh lookahead");
				// System.out.println(zeroLookAheadW);
				co.fillLookAheadW(rFile._getBytes(zeroLookAheadW));
			} else{
				// System.out.println("Diisi seadanya");
				// System.out.println(zeroLookAheadW);
				co.fillLookAheadW(rFile._getBytes((int) rFile.available()));
			}
			
			//Debug
			// System.out.println(co.totalLookAheadW);
			// for (int i = 0; i < co.totalLookAheadW; i++) {
				// System.out.println(co.lookAheadW[i]);
			// }
			
			// System.out.println("total isi search WIndow = " + co.totalSearchW + " total lookahead = " + co.totalLookAheadW);
			
			if (Debug) {
				co.printSearchW();
				co.printLookAheadW();
			}
			
			co.initialization();
			co.trace(nice_length);
			
			System.out.println("--Before--");
			System.out.println("total search: " + co.totalSearchW + ", total lookahead: " + co.totalLookAheadW);
			
			System.out.println("matched: " + co.bestL + ", offset: " + co.bestOffset);
			//If only one OR nothing matched, better output the literal than do lazy search. It do same.
			if (co.bestL < 3) {
				// System.out.println("Kalang: only 1 or nothing matched");
				int ascii = (int) co.getLookAheadW(0);
				if (ascii < 0) ascii += 256;
				dFile.putBitStr(pre.hCodes[ascii]);
				co.fillSearchW(1);
				co.delLookAheadW(1);
				totalUnProcessed--;
				// System.out.println(totalUnProcessed);
			}
			else {
				// System.out.println("testing");
				System.out.println("co.bestL: " + co.bestL + ", max_lazy: " + max_lazy);
				if (co.bestL < max_lazy) { //Do lazy search
					System.out.println("lazySearch()");
					co.lazySearch(nice_length);
				}
				if (co.bestLL > (co.bestL + 2)) {
					System.out.println("Lazy matched: " + co.bestLL + ", offset: " + co.bestOffsetL);
					// System.out.println("Kalang: Sukses lazy search");
					int ascii = (int) co.getLookAheadW(0);
					if (ascii < 0) ascii += 256;
					dFile.putBitStr(pre.hCodes[ascii]);
					co.fillSearchW(1);
					co.delLookAheadW(1);
					totalUnProcessed--;
					
					dFile.putBitStr(pre.getTheOutputLength(co.bestLL));
					dFile.putBitStr(pre.getTheOutputDistance(co.bestOffsetL));
					
					co.fillSearchW(co.bestLL);
					co.delLookAheadW(co.bestLL);
					totalUnProcessed -= co.bestLL;
				}
				else {
					// System.out.println("Kalang: Normal");
					// System.out.println("0");
					dFile.putBitStr(pre.getTheOutputLength(co.bestL));
					// System.out.println("1");
					dFile.putBitStr(pre.getTheOutputDistance(co.bestOffset));
					// System.out.println("2");
					
					co.fillSearchW(co.bestL);
					// System.out.println("3");
					co.delLookAheadW(co.bestL);
					// System.out.println("4");
					totalUnProcessed -= co.bestL;
				}
			}
			System.out.println("--After--");
		}
	}
	
	// class Tuple{
        // int offset, stringLen;
		// String nextChar;
    
		// Tuple(int offset,int stringLen,String nextChar){
			// this.offset = offset;
			// this.stringLen = stringLen;
			// this.nextChar = nextChar;
		// }
		
		// public String toString(){
			// return offset + "," + stringLen + "," + nextChar;
		// }
	// }
	
	//Suplement Code
	String leftPadder(String txt, int n) {
		while(txt.length() < n )
			txt =  "0" + txt;
		return txt;
	}
	
	String rightPadder(String txt,int n){
		while(txt.length() < n )
			txt += "0";
		return txt;
	}
		
	// String complementBinaryStr(String txt){
		// int i = 0;
		// StringBuffer strBuff = new StringBuffer();
		// while(i < (txt.length())) {
			// if(txt.charAt(i) == '0') {
				// strBuff.append("1");
			// }
			// else {
				// strBuff.append("0");
			// }
			// i++;
		// }
		// return new String(strBuff);
	// }
	
	public String fillSearchBuffer(String buff, String fill) {
		int lengthBuff = buff.length();
		int lengthFill = fill.length();
		String ret = "";
		if ((lengthBuff + lengthFill) > 32768) {
			ret = buff + fill;
		}
		else {
			ret = buff.substring(lengthBuff-(32768-lengthFill)) + fill;
		}
		return ret;
	}
	
	public String getSummary(){
		return gSummary;
	}
	
	// StringBuffer getStringBuffer(StringBuffer strBuff, int n) throws Exception{
		// while (n-- > 0) {
			// strBuff.append(rFile.in.read());
		// }
		// return strBuff;
	// }
}